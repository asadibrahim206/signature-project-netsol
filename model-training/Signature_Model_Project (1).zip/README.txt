
Signature Verification - Model Training

Model: Contrastive Siamese CNN
Input Size: 128x128 Grayscale
Total Parameters: 110,080

Test Results:
Accuracy: 64%
ROC-AUC: 0.74
EER: 36%
FAR: 36%
FRR: 36%
ECE: 13.09%

Dataset: Handwritten Signatures
Training: Contrastive Loss
